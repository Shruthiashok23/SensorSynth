"""
pareto.py — NSGA-II Multi-Objective Optimization for Biosensor Architecture Selection

Methodology: True Pareto-optimal frontier across 5 objectives, not weighted sum.
  Based on Otero-Muras & Banga 2017 (ACS Synth Biol) Pareto framework
  applied specifically to architecture–chassis selection problem.

Objectives (all to be MAXIMIZED after normalization):
  1. Dynamic range score      → maximize
  2. Negative burden (-)      → maximize (i.e., minimize burden)
  3. Response speed score     → maximize
  4. Chassis compatibility    → maximize
  5. Evolutionary stability   → maximize

Pareto dominance: solution A dominates B if A ≥ B on all objectives
and A > B on at least one.

Returns:
  - Pareto front (non-dominated solutions)
  - Crowding distances (for visualization)
  - All solutions with rank
"""

import numpy as np
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
from .scoring import compute_score
from .evolution import compute_evolutionary_stability
from .biodata import CHASSIS, ARCHITECTURES


@dataclass
class ParetoSolution:
    arch_id: str
    chassis_id: str
    arch_name: str
    chassis_name: str
    objectives: Dict[str, float]   # objective name → value (all higher = better)
    pareto_rank: int               # 1 = non-dominated front
    crowding_distance: float
    composite_score: float         # for display ordering within rank


def _dominates(a: np.ndarray, b: np.ndarray) -> bool:
    """True if a dominates b: a ≥ b everywhere and a > b somewhere."""
    return bool(np.all(a >= b) and np.any(a > b))


def _fast_nondominated_sort(objectives: np.ndarray) -> List[int]:
    """
    Fast non-dominated sort from Deb 2002 (NSGA-II).
    Returns rank for each solution (1-indexed: rank 1 = Pareto front).
    objectives: (n_solutions, n_objectives) — all objectives higher = better.
    """
    n = len(objectives)
    domination_count = np.zeros(n, dtype=int)     # how many solutions dominate this one
    dominated_by_me   = [[] for _ in range(n)]    # solutions this one dominates
    rank = np.zeros(n, dtype=int)
    fronts = [[]]

    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            if _dominates(objectives[i], objectives[j]):
                dominated_by_me[i].append(j)
            elif _dominates(objectives[j], objectives[i]):
                domination_count[i] += 1
        if domination_count[i] == 0:
            rank[i] = 1
            fronts[0].append(i)

    current_front = 0
    while fronts[current_front]:
        next_front = []
        for i in fronts[current_front]:
            for j in dominated_by_me[i]:
                domination_count[j] -= 1
                if domination_count[j] == 0:
                    rank[j] = current_front + 2
                    next_front.append(j)
        fronts.append(next_front)
        current_front += 1

    return rank.tolist()


def _crowding_distance(objectives: np.ndarray, rank: List[int]) -> np.ndarray:
    """
    Compute crowding distance for solutions in rank 1 (Pareto front).
    High crowding distance = isolated in objective space = diverse = preferred.
    """
    n, m = objectives.shape
    distance = np.zeros(n)
    pareto_idx = [i for i, r in enumerate(rank) if r == 1]

    if len(pareto_idx) <= 2:
        for i in pareto_idx:
            distance[i] = float('inf')
        return distance

    pareto_obj = objectives[pareto_idx]
    for obj_i in range(m):
        sorted_order = np.argsort(pareto_obj[:, obj_i])
        obj_range = pareto_obj[sorted_order[-1], obj_i] - pareto_obj[sorted_order[0], obj_i]
        if obj_range < 1e-10:
            continue
        distance[pareto_idx[sorted_order[0]]]  = float('inf')
        distance[pareto_idx[sorted_order[-1]]] = float('inf')
        for k in range(1, len(sorted_order) - 1):
            distance[pareto_idx[sorted_order[k]]] += (
                pareto_obj[sorted_order[k+1], obj_i] - pareto_obj[sorted_order[k-1], obj_i]
            ) / obj_range

    return distance


def compute_pareto_frontier(spec: dict) -> List[ParetoSolution]:
    """
    Compute Pareto frontier for all architecture × chassis combinations
    given a sensor specification.

    Returns all solutions sorted by (rank, -crowding_distance).
    """
    solutions_raw = []
    objectives_list = []

    for arch in ARCHITECTURES:
        for chassis in CHASSIS:
            # Base compatibility score components
            score_components = compute_score(arch, chassis, spec)

            # Evolutionary stability
            evo = compute_evolutionary_stability(arch, chassis, score_components["burdenFit"])

            # Build objective vector (all to maximize)
            obj_dynamic  = score_components["dynFit"]    / 100.0
            obj_burden   = 1.0 - (arch["burdenCost"] * (1 - chassis["burdenScore"]))  # higher = less burden
            obj_response = score_components["respFit"]   / 100.0
            obj_compat   = score_components["chassisFit"]/ 100.0
            obj_evo      = evo["stability_index"]

            # Clip to [0,1]
            objectives_row = np.clip([obj_dynamic, obj_burden, obj_response, obj_compat, obj_evo], 0, 1)

            solutions_raw.append({
                "arch_id":     arch["id"],
                "chassis_id":  chassis["id"],
                "arch_name":   arch["name"],
                "chassis_name":chassis["full"],
                "objectives": {
                    "dynamic_range":     float(obj_dynamic),
                    "low_burden":        float(obj_burden),
                    "response_speed":    float(obj_response),
                    "chassis_compat":    float(obj_compat),
                    "evol_stability":    float(obj_evo),
                },
                "total_score": score_components["total"],
            })
            objectives_list.append(objectives_row)

    objectives_array = np.array(objectives_list)

    # NSGA-II ranking
    ranks = _fast_nondominated_sort(objectives_array)
    distances = _crowding_distance(objectives_array, ranks)

    pareto_solutions = []
    for i, sol in enumerate(solutions_raw):
        pareto_solutions.append(ParetoSolution(
            arch_id=sol["arch_id"],
            chassis_id=sol["chassis_id"],
            arch_name=sol["arch_name"],
            chassis_name=sol["chassis_name"],
            objectives=sol["objectives"],
            pareto_rank=int(ranks[i]),
            crowding_distance=float(distances[i]) if not np.isinf(distances[i]) else 9999.0,
            composite_score=float(sol["total_score"]),
        ))

    # Sort by (rank, -crowding_distance)
    pareto_solutions.sort(key=lambda s: (s.pareto_rank, -s.crowding_distance))
    return pareto_solutions


def pareto_to_dict(solutions: List[ParetoSolution]) -> List[dict]:
    return [
        {
            "arch_id":          s.arch_id,
            "chassis_id":       s.chassis_id,
            "arch_name":        s.arch_name,
            "chassis_name":     s.chassis_name,
            "objectives":       s.objectives,
            "pareto_rank":      s.pareto_rank,
            "crowding_distance":s.crowding_distance,
            "composite_score":  s.composite_score,
        }
        for s in solutions
    ]

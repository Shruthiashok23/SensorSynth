"""
scoring.py — Compatibility scoring engine
"""

import math
from typing import Dict


def compute_score(arch: dict, chassis: dict, spec: dict) -> Dict[str, float]:
    """
    Compute compatibility score components for one (architecture, chassis, spec) triple.
    Returns dict of component scores [0–100] and total.

    Weights:
      dynFit     0.35  — matches fold-change requirement
      burdenFit  0.30  — metabolic burden vs chassis tolerance
      respFit    0.25  — response kinetics vs max response time
      chassisFit 0.10  — prokaryote/eukaryote domain compatibility
    """
    fold_change     = spec.get("foldChange", 20)
    max_resp_time   = spec.get("maxResponseTime", 3.0)

    # 1. Dynamic range fit
    dyn_fit = arch["dynamicScore"]
    if fold_change > 50  and arch["dynamicScore"] < 0.8:  dyn_fit *= 0.70
    if fold_change < 5   and arch["dynamicScore"] > 0.85: dyn_fit = min(dyn_fit, 0.90)
    if fold_change > 100 and arch["dynamicScore"] < 0.7:  dyn_fit *= 0.55

    # 2. Burden fit
    burden_fit = max(0.0, chassis["burdenScore"] - arch["burdenCost"] * (1.0 - chassis["burdenScore"]))

    # 3. Response time fit
    resp_fit = arch["responseScore"]
    if max_resp_time < 0.5 and arch["responseTime"] == "slow":   resp_fit *= 0.20
    if max_resp_time < 1.0 and arch["responseTime"] == "slow":   resp_fit *= 0.35
    if max_resp_time < 2.0 and arch["responseTime"] == "medium": resp_fit *= 0.80
    if max_resp_time >= 4.0: resp_fit = min(resp_fit + 0.08, 1.0)

    # 4. Chassis compatibility
    chassis_adj = arch["prokaryoticBonus"] if chassis["prokaryotic"] else arch["eukaryoticAdjust"]
    chassis_fit = max(0.0, min(1.0, 0.5 + chassis_adj))

    total = (
        dyn_fit    * 0.35 +
        burden_fit * 0.30 +
        resp_fit   * 0.25 +
        chassis_fit * 0.10
    )

    return {
        "total":      round(min(total, 1.0) * 100),
        "dynFit":     round(dyn_fit    * 100),
        "burdenFit":  round(burden_fit * 100),
        "respFit":    round(resp_fit   * 100),
        "chassisFit": round(chassis_fit * 100),
    }

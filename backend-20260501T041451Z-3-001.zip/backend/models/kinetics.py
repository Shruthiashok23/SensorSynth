"""
kinetics.py — Hill-function ODE simulation with Monte Carlo uncertainty quantification

Methodology: ODE-based kinetic simulation instead of heuristic scores.
Mean ± 2σ confidence bands on dose-response and time-course curves.

Model: dP/dt = alpha_max * f(L) - delta_P * P
At steady state: P_ss = alpha_max * f(L) / delta_P

Fold change = P_ss(L) / P_ss(L=0)  [properly normalized]
"""

import numpy as np
from dataclasses import dataclass
from typing import List, Dict, Tuple
import logging

logger = logging.getLogger(__name__)


@dataclass
class TimePoint:
    t: float
    mean: float
    lower_ci: float
    upper_ci: float


@dataclass
class SimResult:
    arch_id: str
    chassis_id: str
    time_points: List[TimePoint]
    fold_change_mean: float
    fold_change_ci: Tuple[float, float]
    t50_mean: float
    t90_mean: float
    ss_fold_change: float
    n_samples: int


def _rk4_step(f, t, y, dt, params):
    k1 = f(t,        y,               params)
    k2 = f(t + dt/2, y + dt/2 * k1,  params)
    k3 = f(t + dt/2, y + dt/2 * k2,  params)
    k4 = f(t + dt,   y + dt * k3,    params)
    return y + (dt/6) * (k1 + 2*k2 + 2*k3 + k4)


def _hill_activation(L, Kd, n):
    return L**n / (Kd**n + L**n + 1e-30)


def _hill_repression(L, Kd, n):
    return Kd**n / (Kd**n + L**n + 1e-30)


def _ode_generic(t, y, params):
    """
    Unified ODE: dP/dt = alpha_max*(basal + (1-basal)*f(L)) - delta_P*P
    arch_mode: 'activation' | 'repression' | 'tf_derepression'
    """
    P = y[0]
    a = params["alpha_max"]
    d = params["delta_P"]
    Kd = params["Kd"]
    n  = params["n_Hill"]
    L  = params["L"]
    b  = params["alpha_basal"]
    mode = params["mode"]

    if mode == "activation":
        f = _hill_activation(L, Kd, n)
    elif mode == "repression":
        # repressor driven by L — e.g. CRISPRi where L drives dCas9
        f = _hill_repression(L, Kd, n)
    else:  # tf_derepression: ligand L displaces TF from operator
        KI = params.get("KI", 1.0)
        # Fraction of TF still bound at operator (decreases as L increases)
        frac_bound = 1.0 / (1.0 + (L / KI))
        # Output driven by unrepressed fraction
        f = 1.0 - frac_bound**n / ((frac_bound**n) + (Kd / (Kd + frac_bound + 1e-10))**n)
        # Simpler: derepression Hill
        f = _hill_activation(L, KI, n)  # ligand activates by competing with TF

    dP = a * (b + (1.0 - b) * f) - d * P
    return np.array([dP])


def _sample_params(base: dict, rng: np.random.Generator) -> dict:
    """Log-normal sampling of kinetic parameters."""
    s = base.copy()
    s["Kd"]        = base["Kd"]        * np.exp(rng.normal(0, base.get("cv_Kd", 0.30)))
    s["n_Hill"]    = max(0.5, base["n_Hill"] + rng.normal(0, base.get("cv_n", 0.20) * base["n_Hill"]))
    s["alpha_max"] = max(0.1, base["alpha_max"] * np.exp(rng.normal(0, base.get("cv_alpha", 0.25))))
    s["delta_P"]   = max(0.001, base["delta_P"]   * np.exp(rng.normal(0, 0.20)))
    return s


def _compute_ss_fold_change(params: dict) -> float:
    """Analytic steady-state fold change: P_ss(L) / P_ss(L=0)"""
    a   = params["alpha_max"]
    d   = params["delta_P"]
    Kd  = params["Kd"]
    n   = params["n_Hill"]
    L   = params["L"]
    b   = params["alpha_basal"]
    mode = params["mode"]

    if mode == "activation":
        f_L0 = _hill_activation(0.0, Kd, n)
        f_L  = _hill_activation(L,   Kd, n)
    elif mode == "repression":
        f_L0 = _hill_repression(0.0, Kd, n)
        f_L  = _hill_repression(L,   Kd, n)
    else:
        KI = params.get("KI", 1.0)
        f_L0 = _hill_activation(0.0, KI, n)
        f_L  = _hill_activation(L,   KI, n)

    P_ss_0 = a * (b + (1 - b) * f_L0) / d
    P_ss_L = a * (b + (1 - b) * f_L)  / d
    return P_ss_L / (P_ss_0 + 1e-15)


def _get_mode(arch_id: str) -> str:
    modes = {
        "tf_loop":   "tf_derepression",
        "crispri":   "repression",
        "riboswitch":"activation",
        "srna":      "activation",
        "tcs":       "activation",
        "toehold":   "activation",
    }
    return modes.get(arch_id, "activation")


def simulate_architecture(
    arch_id: str,
    arch_params: dict,
    chassis_kinetics: dict,
    ligand_conc: float,
    t_end: float,
    n_monte_carlo: int = 120,
    n_time_points: int = 60,
    rng_seed: int = 42,
) -> SimResult:
    rng = np.random.default_rng(rng_seed)
    times = np.linspace(0, t_end, n_time_points)
    dt = times[1] - times[0]
    mode = _get_mode(arch_id)

    all_fc_traces = []

    for _ in range(n_monte_carlo):
        sp = _sample_params(arch_params, rng)
        sp["L"]    = ligand_conc
        sp["mode"] = mode

        # Compute steady-state fold change at this ligand concentration
        ss_fc = _compute_ss_fold_change(sp)
        ss_fc = max(1.0, ss_fc)

        # Kinetic trace: protein approaches steady state
        delta_eff = sp["delta_P"]
        # P(t) / P_ss_L = 1 - exp(-delta_P * t)   [from uninduced state]
        trace = ss_fc * (1.0 - np.exp(-delta_eff * times))
        trace = np.maximum(trace, 1.0)  # fold change >= 1

        all_fc_traces.append(trace)

    traces = np.array(all_fc_traces)
    mean_trace = np.mean(traces, axis=0)
    p5_trace   = np.percentile(traces, 5,  axis=0)
    p95_trace  = np.percentile(traces, 95, axis=0)

    ss_fc_samples = traces[:, -1]
    fc_mean  = float(np.mean(ss_fc_samples))
    fc_p5    = float(np.percentile(ss_fc_samples, 5))
    fc_p95   = float(np.percentile(ss_fc_samples, 95))

    # t50, t90 from mean trace
    target50 = 0.5 * mean_trace[-1]
    target90 = 0.9 * mean_trace[-1]
    t50 = t_end
    t90 = t_end
    for i, val in enumerate(mean_trace):
        if val >= target50 and t50 == t_end: t50 = float(times[i])
        if val >= target90 and t90 == t_end: t90 = float(times[i])

    time_points = [
        TimePoint(
            t=float(times[i]),
            mean=float(mean_trace[i]),
            lower_ci=float(p5_trace[i]),
            upper_ci=float(p95_trace[i]),
        )
        for i in range(n_time_points)
    ]

    return SimResult(
        arch_id=arch_id, chassis_id="",
        time_points=time_points,
        fold_change_mean=fc_mean,
        fold_change_ci=(fc_p5, fc_p95),
        t50_mean=t50, t90_mean=t90,
        ss_fold_change=fc_mean,
        n_samples=n_monte_carlo,
    )


def compute_dose_response(
    arch_id: str,
    arch_params: dict,
    chassis_kinetics: dict,
    t_sim: float = 6.0,
    n_doses: int = 30,
    L_min: float = 1e-3,
    L_max: float = 1e3,
    n_mc: int = 60,
) -> List[dict]:
    doses = np.logspace(np.log10(L_min), np.log10(L_max), n_doses)
    results = []
    mode = _get_mode(arch_id)
    rng = np.random.default_rng(99)

    for L in doses:
        fcs = []
        for _ in range(n_mc):
            sp = _sample_params(arch_params, rng)
            sp["L"] = L; sp["mode"] = mode
            fc = _compute_ss_fold_change(sp)
            fcs.append(max(1.0, fc))
        fcs = np.array(fcs)
        results.append({
            "L":        float(L),
            "mean_fc":  float(np.mean(fcs)),
            "lower_ci": float(np.percentile(fcs, 5)),
            "upper_ci": float(np.percentile(fcs, 95)),
        })
    return results

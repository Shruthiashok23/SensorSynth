"""
evolutionary_stability.py — Predict circuit evolutionary half-life

Methodology: Quantifies how quickly a given circuit in a given chassis will be
  silenced or mutated away under natural selection pressure.

  Based on:
  - Sleight et al. 2010 (J Biol Eng) — metabolic burden drives circuit loss
  - Helenek et al. 2024 (Chem Biol)  — mid-scale evolution of gene circuits
  - Theoretical framework: Moran process approximation

  Stability Index = 1 / (1 + λ_loss)
  where λ_loss = k_mut × burden_factor × N_components / essentiality_protection

  Half-life in generations:
  T_half = ln(2) / λ_loss
"""

import math
from typing import Dict


# Base mutation rates per component per generation (order-of-magnitude estimates)
COMPONENT_MUTATION_RATES = {
    "crispri":    3.0e-7,   # large gene = more mutation targets
    "riboswitch": 5.0e-8,   # RNA element, small
    "tf_loop":    1.5e-7,   # protein-coding TF
    "srna":       6.0e-8,   # small RNA
    "tcs":        2.5e-7,   # two protein components
    "toehold":    4.0e-8,   # RNA switch, small
}


def compute_evolutionary_stability(
    arch: dict,
    chassis: dict,
    burden_fit: float,   # 0–100 (from scoring engine, higher = less burden)
) -> Dict:
    """
    Returns evolutionary stability metrics for one arch × chassis combination.

    Returns:
      stability_index    — 0 to 1 (1 = very stable, 0 = rapidly lost)
      half_life_gen      — expected generations until 50% of cells have lost circuit
      half_life_hours    — same, converted to hours using chassis doubling time
      loss_rate          — λ_loss (1/generation)
      risk_level         — "Low" | "Medium" | "High"
    """
    arch_id = arch["id"]

    # Burden penalty: high burden = faster loss
    # burden_fit is 0–100 where 100 = no burden; convert to 0–1 where 1 = max burden
    relative_burden = 1.0 - (burden_fit / 100.0)

    # Base mutation rate per component
    k_base = COMPONENT_MUTATION_RATES.get(arch_id, 2e-7)

    # Component count amplifies mutation target size
    n_components = arch.get("componentCount", 2)

    # Chassis mutation rate (multiplier)
    chassis_mut = chassis.get("mutationRate", 1e-10) / 1e-10  # normalized to E. coli

    # Essentiality protection: essential circuits are maintained by selection
    essentiality = arch.get("essentialityScore", 0.0)
    protection_factor = 1.0 + 5.0 * essentiality  # max 6× protection if fully essential

    # Compute loss rate (1/generation)
    loss_rate = (k_base * n_components * chassis_mut * (0.5 + 1.5 * relative_burden)) / protection_factor

    # Half-life in generations
    half_life_gen = math.log(2) / (loss_rate + 1e-15)
    half_life_hours = half_life_gen * chassis["doublingTime"]

    # Stability index: logistic mapping so it's bounded 0–1
    # ESI = 1 / (1 + exp(-k*(T_half - T_threshold)))
    T_threshold = 1000.0  # generations
    esi = 1.0 / (1.0 + math.exp(-(half_life_gen - T_threshold) / 300.0))

    # Risk classification
    if esi >= 0.70:  risk = "Low"
    elif esi >= 0.40: risk = "Medium"
    else:             risk = "High"

    return {
        "stability_index":  round(esi, 4),
        "half_life_gen":    round(half_life_gen),
        "half_life_hours":  round(half_life_hours, 1),
        "loss_rate":        round(loss_rate, 8),
        "risk_level":       risk,
        "relative_burden":  round(relative_burden, 3),
        "n_mutation_targets": n_components,
    }

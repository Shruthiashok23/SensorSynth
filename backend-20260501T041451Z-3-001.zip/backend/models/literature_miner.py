"""
literature_miner.py

Architecture (fixed for production):
  - PubMed search and abstract fetching happen BROWSER-SIDE via the JS client
    using NCBI E-utilities directly (no CORS restrictions from browser).
  - The backend receives pre-fetched abstracts and runs Claude extraction.
  - This bypasses any server-side network restrictions on NCBI.

Two endpoints:
  POST /api/literature/extract-metrics  — given a list of {pmid, title, abstract},
                                           run Claude extraction on each and return results
  GET  /api/literature/pubmed-proxy     — optional server-side proxy if browser prefers it
                                           (returns 501 if NCBI unreachable from server)
"""

import os
import json
import asyncio
import httpx
from typing import List, Dict, Optional
import logging

logger = logging.getLogger(__name__)

EXTRACTION_PROMPT = """You are a synthetic biology data extraction assistant. Extract quantitative biosensor performance metrics from the abstract below.

Abstract:
{abstract}

Return ONLY a valid JSON object with exactly these fields (use null for missing values):
{{
  "fold_change": <number or null>,
  "kd_uM": <number or null — binding constant in micromolar>,
  "hill_coefficient": <number or null>,
  "response_time_h": <number or null — convert to hours>,
  "detection_limit_uM": <number or null — convert to micromolar>,
  "chassis": <string or null — organism name>,
  "architecture_type": <"TF-based"|"riboswitch"|"CRISPRi"|"sRNA"|"TCS"|"toehold"|"other"|null>,
  "analyte": <string or null — the molecule being detected>,
  "confidence": <0.0 to 1.0 — how many explicit numeric values were found>,
  "extraction_notes": <one sentence explaining what was found>
}}

Rules:
- Only include values explicitly stated in the abstract. Do not infer.
- Convert all concentrations to micromolar (µM).
- confidence=1.0 means multiple clear numeric values; confidence=0.2 means qualitative only.
- Return ONLY the JSON, no markdown, no explanation."""


async def extract_with_claude(abstract: str, api_key: str) -> Dict:
    """Call Claude API to extract metrics from a single abstract."""
    if not abstract or len(abstract.strip()) < 30:
        return {"error": "Abstract too short", "confidence": 0.0}

    try:
        async with httpx.AsyncClient(timeout=25.0) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": "claude-haiku-4-5-20251001",
                    "max_tokens": 400,
                    "messages": [{
                        "role": "user",
                        "content": EXTRACTION_PROMPT.format(abstract=abstract[:2500])
                    }]
                }
            )
            if resp.status_code == 401:
                return {"error": "Invalid API key", "confidence": 0.0, "extraction_method": "claude-api"}
            if resp.status_code == 429:
                return {"error": "Rate limit — try again in a moment", "confidence": 0.0, "extraction_method": "claude-api"}
            if resp.status_code != 200:
                return {"error": f"Claude API error {resp.status_code}", "confidence": 0.0, "extraction_method": "claude-api"}

            data = resp.json()
            raw_text = data["content"][0]["text"].strip()

            # Strip markdown code fences if present
            if raw_text.startswith("```"):
                raw_text = raw_text.split("```")[1]
                if raw_text.startswith("json"):
                    raw_text = raw_text[4:]
            raw_text = raw_text.strip()

            result = json.loads(raw_text)
            result["extraction_method"] = "claude-api"
            return result

    except json.JSONDecodeError as e:
        return {"error": f"JSON parse failed: {str(e)}", "confidence": 0.0, "extraction_method": "claude-api"}
    except Exception as e:
        logger.warning(f"Claude extraction error: {e}")
        return {"error": str(e), "confidence": 0.0, "extraction_method": "claude-api"}


def heuristic_extract(abstract: str) -> Dict:
    """
    Regex-based fallback when no API key is provided.
    Extracts common patterns from biosensor abstracts.
    """
    import re
    text_lower = abstract.lower()
    result = {
        "fold_change": None, "kd_uM": None, "hill_coefficient": None,
        "response_time_h": None, "detection_limit_uM": None,
        "chassis": None, "architecture_type": None, "analyte": None,
        "confidence": 0.15,
        "extraction_method": "heuristic (no API key provided)",
        "extraction_notes": "Pattern-based extraction — add an Anthropic API key for accurate LLM extraction.",
    }

    # Fold-change patterns
    patterns_fc = [
        r'(\d+(?:\.\d+)?)\s*[-–]\s*fold', r'fold.{0,10}?(\d+(?:\.\d+)?)',
        r'(\d+(?:\.\d+)?)\s*fold.{0,5}induction', r'(\d+(?:\.\d+)?)[xX×]\s*induction',
    ]
    for pat in patterns_fc:
        m = re.search(pat, text_lower)
        if m:
            try:
                result["fold_change"] = float(m.group(1))
                result["confidence"] = max(result["confidence"], 0.45)
                break
            except (ValueError, IndexError):
                pass

    # Hill coefficient
    m = re.search(r'hill coefficient[^\d]*(\d+(?:\.\d+)?)', text_lower)
    if m:
        try:
            result["hill_coefficient"] = float(m.group(1))
            result["confidence"] = max(result["confidence"], 0.5)
        except ValueError:
            pass

    # Response time
    time_patterns = [
        (r'within (\d+(?:\.\d+)?)\s*min', 1/60),
        (r'(\d+(?:\.\d+)?)\s*min(?:ute)', 1/60),
        (r'(\d+(?:\.\d+)?)\s*h(?:our|r)', 1.0),
    ]
    for pat, mult in time_patterns:
        m = re.search(pat, text_lower)
        if m:
            try:
                result["response_time_h"] = round(float(m.group(1)) * mult, 3)
                result["confidence"] = max(result["confidence"], 0.4)
                break
            except ValueError:
                pass

    # Architecture
    arch_map = [
        (["crispri","dcas9","dcas9"], "CRISPRi"),
        (["riboswitch","aptamer"], "riboswitch"),
        (["toehold switch","toehold"], "toehold"),
        (["small rna","srna","ncrna","hfq"], "sRNA"),
        (["two-component","histidine kinase","response regulator"], "TCS"),
        (["transcription factor","laci","tetr","arac","repressor"], "TF-based"),
    ]
    for keywords, arch_type in arch_map:
        if any(kw in text_lower for kw in keywords):
            result["architecture_type"] = arch_type
            break

    # Chassis
    chassis_map = [
        (["escherichia coli","e. coli","e.coli"], "E. coli"),
        (["bacillus subtilis","b. subtilis"], "B. subtilis"),
        (["saccharomyces cerevisiae","s. cerevisiae","yeast"], "S. cerevisiae"),
        (["pseudomonas"], "P. putida"),
        (["corynebacterium"], "C. glutamicum"),
        (["vibrio natriegens"], "V. natriegens"),
        (["mammalian","hek293","cho cell"], "Mammalian"),
        (["cell-free","in vitro","cell free"], "Cell-free"),
    ]
    for keywords, chassis in chassis_map:
        if any(kw in text_lower for kw in keywords):
            result["chassis"] = chassis
            break

    return result


async def extract_metrics_batch(
    articles: List[Dict],  # [{pmid, title, abstract, ...}]
    api_key: Optional[str] = None,
) -> List[Dict]:
    """
    Run extraction on a list of pre-fetched articles.
    Each article dict must contain at least: pmid, title, abstract.
    Returns the articles list with 'extracted' field added to each.
    """
    use_claude = bool(api_key and api_key.startswith("sk-ant"))
    results = []

    for article in articles:
        abstract = article.get("abstract", "").strip()
        if not abstract:
            extracted = {"error": "No abstract provided", "confidence": 0.0}
        elif use_claude:
            extracted = await extract_with_claude(abstract, api_key)
        else:
            extracted = heuristic_extract(abstract)

        results.append({**article, "extracted": extracted})

    return results


def aggregate_metrics(articles_with_extractions: List[Dict]) -> Dict:
    """Compute summary statistics over all extracted metrics."""
    import statistics

    def extract_numbers(field):
        return [
            a["extracted"][field]
            for a in articles_with_extractions
            if isinstance(a.get("extracted", {}).get(field), (int, float))
        ]

    def safe_stats(data):
        if not data:
            return {"n": 0, "mean": None, "median": None, "min": None, "max": None}
        return {
            "n": len(data),
            "mean": round(statistics.mean(data), 3),
            "median": round(statistics.median(data), 3),
            "min": round(min(data), 3),
            "max": round(max(data), 3),
        }

    from collections import Counter
    arch_types = [a["extracted"].get("architecture_type") for a in articles_with_extractions
                  if a.get("extracted", {}).get("architecture_type")]
    chassis_list = [a["extracted"].get("chassis") for a in articles_with_extractions
                    if a.get("extracted", {}).get("chassis")]

    high_confidence = sum(
        1 for a in articles_with_extractions
        if a.get("extracted", {}).get("confidence", 0) >= 0.35
    )

    return {
        "fold_change": safe_stats(extract_numbers("fold_change")),
        "response_time_h": safe_stats(extract_numbers("response_time_h")),
        "kd_uM": safe_stats(extract_numbers("kd_uM")),
        "hill_coefficient": safe_stats(extract_numbers("hill_coefficient")),
        "arch_type_freq": dict(Counter(arch_types)),
        "chassis_freq": dict(Counter(chassis_list)),
        "n_total": len(articles_with_extractions),
        "n_with_data": high_confidence,
        "extraction_method": "claude-api" if any(
            a.get("extracted", {}).get("extraction_method") == "claude-api"
            for a in articles_with_extractions
        ) else "heuristic",
    }

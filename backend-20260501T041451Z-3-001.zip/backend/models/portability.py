"""
portability.py — Cross-Chassis Portability Transfer Model

Methodology: Predicts circuit performance in a TARGET chassis given characterization
  in a SOURCE chassis, using the empirical linear relationship discovered
  by Qin et al. 2024 (Quantitative Biology).

  Transfer model:
    perf_target = slope(src, tgt) × perf_source × arch_correction

  Extended with feature-based similarity:
    slope = w_phylo × phylo_sim + w_sigma × sigma_compat +
            w_ribo  × ribo_sim  + w_gc    × gc_sim       +
            w_growth × growth_sim

  Uncertainty:
    95% CI = slope ± 1.96 × σ_slope (bootstrapped from Qin 2024 data)
    σ_slope ≈ 0.15 (estimated from paper's reported variance)
"""

import math
import numpy as np
from typing import Dict, List, Tuple
from .biodata import CHASSIS, ARCHITECTURES, TRANSFER_SLOPE_MATRIX, ARCH_PORTABILITY_CORRECTION, CHASSIS_FEATURE_WEIGHTS


def _get_chassis(chassis_id: str) -> dict:
    return next((c for c in CHASSIS if c["id"] == chassis_id), None)


def _get_arch(arch_id: str) -> dict:
    return next((a for a in ARCHITECTURES if a["id"] == arch_id), None)


def _feature_similarity(src: dict, tgt: dict) -> Dict:
    """
    Compute feature-level similarity between two chassis.
    Returns dict of similarity scores and weighted composite.
    """
    # 1. Phylogenetic similarity proxy (both prokaryotic or not)
    same_domain = int(src["prokaryotic"] == tgt["prokaryotic"])
    # Refine: Gram +/- difference within prokaryotes
    if same_domain and src["prokaryotic"]:
        gram_positive_ids = {"bsubtilis", "cglutamicum"}
        src_gp = src["id"] in gram_positive_ids
        tgt_gp = tgt["id"] in gram_positive_ids
        phylo_sim = 0.85 if src_gp == tgt_gp else 0.60
    elif same_domain:
        phylo_sim = 1.0  # both eukaryotes
    else:
        phylo_sim = 0.10  # cross-domain: prokaryote ↔ eukaryote

    # 2. Sigma factor compatibility
    src_sigmas = set(src.get("sigmaFactors", []))
    tgt_sigmas = set(tgt.get("sigmaFactors", []))
    if src_sigmas or tgt_sigmas:
        sigma_compat = len(src_sigmas & tgt_sigmas) / max(len(src_sigmas | tgt_sigmas), 1)
    else:
        sigma_compat = 0.5 if not src_sigmas and not tgt_sigmas else 0.0

    # 3. Ribosome speed ratio (closer ratio = better translation compatibility)
    rs_ratio = min(src["ribosomeSpeed"], tgt["ribosomeSpeed"]) / max(src["ribosomeSpeed"], tgt["ribosomeSpeed"])

    # 4. GC content similarity
    gc_diff = abs(src["gcContent"] - tgt["gcContent"])
    gc_sim  = math.exp(-gc_diff / 20.0)  # decay with ~20% GC difference scale

    # 5. Growth rate ratio (kinetic compatibility)
    gr_ratio = min(src["doublingTime"], tgt["doublingTime"]) / max(src["doublingTime"], tgt["doublingTime"])

    # Weighted composite
    w = CHASSIS_FEATURE_WEIGHTS
    composite = (
        w[0] * phylo_sim +
        w[1] * sigma_compat +
        w[2] * rs_ratio +
        w[3] * gc_sim +
        w[4] * gr_ratio
    )

    return {
        "phylo_sim":    round(phylo_sim, 3),
        "sigma_compat": round(sigma_compat, 3),
        "ribo_speed_sim": round(rs_ratio, 3),
        "gc_sim":       round(gc_sim, 3),
        "growth_sim":   round(gr_ratio, 3),
        "composite":    round(composite, 3),
    }


def compute_portability(
    arch_id: str,
    source_chassis_id: str,
    target_chassis_id: str,
    source_score: float,    # 0–100 performance in source chassis
) -> Dict:
    """
    Predict performance of arch_id in target_chassis given source_score in source_chassis.

    Returns:
      predicted_score     — predicted performance in target (0–100)
      ci_lower, ci_upper  — 95% CI
      transfer_slope      — used slope
      feature_similarity  — per-feature breakdown
      confidence          — "High" | "Medium" | "Low"
    """
    if source_chassis_id == target_chassis_id:
        return {
            "predicted_score": source_score,
            "ci_lower":        source_score,
            "ci_upper":        source_score,
            "transfer_slope":  1.0,
            "arch_correction": 1.0,
            "feature_similarity": {},
            "confidence":      "High",
            "note": "Same chassis — no transfer needed.",
        }

    src = _get_chassis(source_chassis_id)
    tgt = _get_chassis(target_chassis_id)
    arch = _get_arch(arch_id)

    if not src or not tgt or not arch:
        return {"error": "Unknown chassis or architecture ID"}

    # Look up empirical slope from matrix
    empirical_slope = TRANSFER_SLOPE_MATRIX.get(
        (source_chassis_id, target_chassis_id), 0.5
    )

    # Feature similarity (refinement)
    feat_sim = _feature_similarity(src, tgt)

    # Blend empirical and feature-based slope (70/30 weighting)
    blended_slope = 0.70 * empirical_slope + 0.30 * feat_sim["composite"]

    # Architecture-specific correction
    arch_correction = ARCH_PORTABILITY_CORRECTION.get(arch_id, 0.85)

    # Final transfer slope
    transfer_slope = blended_slope * arch_correction

    # Predicted score
    predicted = min(100.0, transfer_slope * source_score)

    # Uncertainty: σ ≈ 0.15 × slope (Qin 2024 bootstrapped variance estimate)
    sigma_slope = 0.15
    ci_half     = 1.96 * sigma_slope * source_score
    ci_lower    = max(0.0,   predicted - ci_half)
    ci_upper    = min(100.0, predicted + ci_half)

    # Confidence based on feature similarity and slope magnitude
    if feat_sim["composite"] > 0.65 and blended_slope > 0.70:
        confidence = "High"
    elif feat_sim["composite"] > 0.40 or blended_slope > 0.50:
        confidence = "Medium"
    else:
        confidence = "Low"

    return {
        "predicted_score":  round(predicted, 1),
        "ci_lower":         round(ci_lower, 1),
        "ci_upper":         round(ci_upper, 1),
        "transfer_slope":   round(transfer_slope, 3),
        "arch_correction":  round(arch_correction, 3),
        "feature_similarity": feat_sim,
        "confidence":       confidence,
        "source_chassis":   src["full"],
        "target_chassis":   tgt["full"],
        "note": f"Based on Qin et al. 2024 linear transfer model with {arch_id} correction.",
    }


def compute_portability_matrix(arch_id: str, source_chassis_id: str, source_score: float) -> List[Dict]:
    """
    Compute portability predictions for arch_id from source_chassis to all other chassis.
    """
    results = []
    for tgt in CHASSIS:
        result = compute_portability(arch_id, source_chassis_id, tgt["id"], source_score)
        result["target_chassis_id"]   = tgt["id"]
        result["target_chassis_name"] = tgt["full"]
        result["target_chassis_color"] = tgt["color"]
        results.append(result)
    results.sort(key=lambda r: r.get("predicted_score", 0), reverse=True)
    return results

"""
main.py — BioSensorForge API

Genetic circuit architecture and chassis selection engine.
"""

import os
import logging
from typing import Optional, List

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from models.biodata import CHASSIS, ARCHITECTURES, VALIDATION_CASES
from models.scoring import compute_score
from models.kinetics import simulate_architecture, compute_dose_response
from models.pareto import compute_pareto_frontier, pareto_to_dict
from models.portability import compute_portability, compute_portability_matrix
from models.evolution import compute_evolutionary_stability
from models.literature_miner import extract_metrics_batch, aggregate_metrics

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="BioSensorForge API",
    description="Compatibility-aware automated sensor architecture and chassis selection engine.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Request / Response Models ─────────────────────────────────────────────────

class SensorSpec(BaseModel):
    targetMolecule:     str   = "Arsenic"
    targetType:         str   = "Small molecule (inorganic ion)"
    detectionThreshold: float = 10.0
    thresholdUnit:      str   = "ppb"
    foldChange:         float = Field(20.0, ge=1)
    maxResponseTime:    float = Field(2.0, ge=0.1)
    outputType:         str   = "Fluorescence (GFP/mCherry)"
    environment:        str   = "Aqueous solution"
    hostId:             str   = "ecoli"
    strainId:           str   = "mg1655"

class KineticsRequest(BaseModel):
    archId:      str
    chassisId:   str
    ligandConc:  float = Field(1.0, gt=0)
    tEnd:        float = Field(6.0, gt=0)
    nMonteCarlo: int   = Field(120, ge=10, le=500)

class DoseResponseRequest(BaseModel):
    archId:    str
    chassisId: str
    tSim:      float = 6.0
    nDoses:    int   = 30
    LMin:      float = 0.001
    LMax:      float = 1000.0

class PortabilityRequest(BaseModel):
    archId:        str
    sourceChassis: str
    targetChassis: str
    sourceScore:   float = Field(75.0, ge=0, le=100)

class PortabilityMatrixRequest(BaseModel):
    archId:        str
    sourceChassis: str
    sourceScore:   float = Field(75.0, ge=0, le=100)

class ArticleForExtraction(BaseModel):
    pmid:     str
    title:    str
    abstract: str
    authors:  Optional[str] = ""
    journal:  Optional[str] = ""
    year:     Optional[str] = ""
    url:      Optional[str] = ""

class LiteratureExtractRequest(BaseModel):
    articles: List[ArticleForExtraction]
    apiKey:   Optional[str] = None

# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/api/health")
def health():
    return {"status": "ok", "version": "1.0.0", "service": "BioSensorForge"}


@app.get("/api/chassis")
def get_chassis():
    return [{k: v for k, v in c.items() if k != "kinetics"} for c in CHASSIS]


@app.get("/api/architectures")
def get_architectures():
    return [{k: v for k, v in a.items() if k not in ("kineticParams",)} for a in ARCHITECTURES]


@app.post("/api/score/matrix")
def score_matrix(spec: SensorSpec):
    spec_dict = spec.model_dump()
    matrix = []
    for arch in ARCHITECTURES:
        row = {"arch_id": arch["id"], "arch_name": arch["name"], "scores": {}}
        for chassis in CHASSIS:
            row["scores"][chassis["id"]] = compute_score(arch, chassis, spec_dict)
        matrix.append(row)
    return {"matrix": matrix, "spec": spec_dict}


@app.post("/api/score/ranked")
def score_ranked(spec: SensorSpec):
    spec_dict = spec.model_dump()
    chassis = next((c for c in CHASSIS if c["id"] == spec.hostId), None)
    if not chassis:
        raise HTTPException(400, f"Unknown chassisId: {spec.hostId}")
    results = []
    for arch in ARCHITECTURES:
        score = compute_score(arch, chassis, spec_dict)
        evo   = compute_evolutionary_stability(arch, chassis, score["burdenFit"])
        results.append({
            "arch":      {k: v for k, v in arch.items() if k not in ("kineticParams",)},
            "chassis":   {k: v for k, v in chassis.items() if k != "kinetics"},
            "score":     score,
            "evolution": evo,
        })
    results.sort(key=lambda r: r["score"]["total"], reverse=True)
    return {"ranked": results, "spec": spec_dict}


@app.post("/api/kinetics/simulate")
def kinetics_simulate(req: KineticsRequest):
    arch    = next((a for a in ARCHITECTURES if a["id"] == req.archId), None)
    chassis = next((c for c in CHASSIS if c["id"] == req.chassisId), None)
    if not arch or not chassis:
        raise HTTPException(400, "Unknown archId or chassisId")
    params = {**arch.get("kineticParams", {})}
    params["delta_P"] = chassis["kinetics"]["proteinDegRate"] + chassis["kinetics"]["dilutionRate"]
    try:
        result = simulate_architecture(
            arch_id=req.archId, arch_params=params, chassis_kinetics=chassis["kinetics"],
            ligand_conc=req.ligandConc, t_end=req.tEnd,
            n_monte_carlo=req.nMonteCarlo, n_time_points=60,
        )
        return {
            "arch_id": result.arch_id, "chassis_id": req.chassisId,
            "time_points": [{"t": tp.t, "mean": round(tp.mean, 3),
                             "lower_ci": round(tp.lower_ci, 3),
                             "upper_ci": round(tp.upper_ci, 3)}
                            for tp in result.time_points],
            "fold_change_mean": round(result.fold_change_mean, 2),
            "fold_change_ci": [round(result.fold_change_ci[0], 2), round(result.fold_change_ci[1], 2)],
            "t50_h": round(result.t50_mean, 3),
            "t90_h": round(result.t90_mean, 3),
            "n_mc_samples": result.n_samples,
        }
    except Exception as e:
        logger.exception("Kinetics error")
        raise HTTPException(500, str(e))


@app.post("/api/kinetics/dose-response")
def dose_response(req: DoseResponseRequest):
    arch    = next((a for a in ARCHITECTURES if a["id"] == req.archId), None)
    chassis = next((c for c in CHASSIS if c["id"] == req.chassisId), None)
    if not arch or not chassis:
        raise HTTPException(400, "Unknown archId or chassisId")
    params = {**arch.get("kineticParams", {})}
    params["delta_P"] = chassis["kinetics"]["proteinDegRate"] + chassis["kinetics"]["dilutionRate"]
    try:
        curve = compute_dose_response(
            arch_id=req.archId, arch_params=params, chassis_kinetics=chassis["kinetics"],
            t_sim=req.tSim, n_doses=req.nDoses, L_min=req.LMin, L_max=req.LMax, n_mc=60,
        )
        return {"arch_id": req.archId, "chassis_id": req.chassisId, "curve": curve}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.post("/api/pareto/compute")
def pareto_compute(spec: SensorSpec):
    try:
        solutions  = compute_pareto_frontier(spec.model_dump())
        data       = pareto_to_dict(solutions)
        pareto_front = [s for s in data if s["pareto_rank"] == 1]
        return {"all_solutions": data, "pareto_front": pareto_front,
                "n_solutions": len(data), "n_pareto": len(pareto_front)}
    except Exception as e:
        raise HTTPException(500, str(e))


@app.post("/api/portability/transfer")
def portability_transfer(req: PortabilityRequest):
    result = compute_portability(req.archId, req.sourceChassis, req.targetChassis, req.sourceScore)
    if "error" in result:
        raise HTTPException(400, result["error"])
    return result


@app.post("/api/portability/matrix")
def portability_matrix(req: PortabilityMatrixRequest):
    results = compute_portability_matrix(req.archId, req.sourceChassis, req.sourceScore)
    return {"arch_id": req.archId, "source_chassis": req.sourceChassis, "predictions": results}


@app.post("/api/evolution/batch")
def evolution_batch(spec: SensorSpec):
    spec_dict = spec.model_dump()
    results = []
    for arch in ARCHITECTURES:
        for chassis in CHASSIS:
            score = compute_score(arch, chassis, spec_dict)
            evo   = compute_evolutionary_stability(arch, chassis, score["burdenFit"])
            results.append({
                "arch_id": arch["id"], "arch_name": arch["name"],
                "chassis_id": chassis["id"], "chassis_name": chassis["full"],
                "evolution": evo, "burden_fit": score["burdenFit"],
            })
    results.sort(key=lambda r: r["evolution"]["stability_index"], reverse=True)
    return {"results": results}


@app.post("/api/literature/extract-metrics")
async def literature_extract(req: LiteratureExtractRequest):
    """
    Receive pre-fetched articles (with abstracts) from the browser,
    run Claude or heuristic extraction on each, return results + aggregated stats.
    """
    api_key = req.apiKey or os.getenv("ANTHROPIC_API_KEY", "")
    articles = [a.model_dump() for a in req.articles]
    try:
        results    = await extract_metrics_batch(articles, api_key if api_key else None)
        aggregated = aggregate_metrics(results)
        return {"results": results, "aggregated": aggregated, "n_articles": len(results)}
    except Exception as e:
        logger.exception("Literature extraction error")
        raise HTTPException(500, str(e))


@app.get("/api/validation")
def validation():
    results = []
    for case in VALIDATION_CASES:
        arch    = next((a for a in ARCHITECTURES if a["id"] == case["arch"]),    None)
        chassis = next((c for c in CHASSIS      if c["id"] == case["chassis"]), None)
        if not arch or not chassis:
            continue
        spec  = {"foldChange": 20, "maxResponseTime": 3.0, "hostId": chassis["id"]}
        score = compute_score(arch, chassis, spec)
        evo   = compute_evolutionary_stability(arch, chassis, score["burdenFit"])
        predicted_high = score["total"] >= 65
        results.append({
            **case,
            "score":          score,
            "evolution":      evo,
            "predicted_high": predicted_high,
            "match":          predicted_high == case["expectedHigh"],
            "arch_name":      arch["name"],
            "chassis_name":   chassis["full"],
            "arch_color":     arch["color"],
            "chassis_color":  chassis["color"],
        })
    concordance = sum(1 for r in results if r["match"]) / len(results) if results else 0
    return {
        "cases": results,
        "concordance": round(concordance * 100, 1),
        "n_cases": len(results),
        "n_matches": sum(1 for r in results if r["match"]),
    }


@app.get("/api/tools")
def tools():
    return {"tools": [
        {"name":"Cello",          "url":"https://cellocad.org",                          "category":"Circuit design",   "desc":"Automated genetic logic circuit design from truth tables"},
        {"name":"SynBioHub",      "url":"https://synbiohub.org",                         "category":"Parts registry",   "desc":"SBOL-based repository of characterized genetic parts"},
        {"name":"iGEM Registry",  "url":"https://parts.igem.org",                        "category":"Parts registry",   "desc":"Community parts registry — promoters, RBSs, coding sequences"},
        {"name":"iBioSim",        "url":"https://async.ece.utah.edu/ibiosim",             "category":"Modeling",         "desc":"ODE/stochastic simulation of genetic regulatory networks"},
        {"name":"NUPACK",         "url":"http://www.nupack.org",                         "category":"RNA tools",        "desc":"Thermodynamic design and folding of RNA/DNA toehold structures"},
        {"name":"IntaRNA",        "url":"https://cobi.informatik.uni-freiburg.de/IntaRNA","category":"RNA tools",        "desc":"sRNA–mRNA interaction energy and binding site prediction"},
        {"name":"CRISPRscan",     "url":"https://www.crisprscan.org",                    "category":"CRISPR tools",     "desc":"sgRNA efficacy scoring and off-target analysis"},
        {"name":"COBRA Toolbox",  "url":"https://opencobra.github.io/cobratoolbox",      "category":"Metabolic models", "desc":"Flux balance analysis for metabolic burden prediction"},
        {"name":"P2CS Database",  "url":"http://www.p2cs.org",                          "category":"Databases",        "desc":"Prokaryotic 2-component system database"},
        {"name":"KEGG PATHWAY",   "url":"https://www.genome.jp/kegg/pathway",            "category":"Databases",        "desc":"Metabolite pathway maps for analyte context analysis"},
        {"name":"Vienna RNA",     "url":"https://www.tbi.univie.ac.at/RNA",              "category":"RNA tools",        "desc":"RNA secondary structure folding and design"},
        {"name":"OpenTrons",      "url":"https://opentrons.com",                         "category":"Lab automation",   "desc":"Open-source liquid handling robot — Python protocol scripting"},
    ]}
